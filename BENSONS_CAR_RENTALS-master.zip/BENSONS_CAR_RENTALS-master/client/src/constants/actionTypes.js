export const AAUTH = 'AAUTH';
export const ALOGOUT = 'ALOGOUT';
export const FETCH_ALL = 'FETCH_ALL';
export const DELETE = 'DELETE';

export const AUTH = 'AUTH';
export const LOGOUT = 'LOGOUT';

